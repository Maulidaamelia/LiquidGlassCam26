package com.liquidglasscam26;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.*;
import android.media.MediaRecorder;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    CameraController camera; LiquidUI ui;
    static final int REQ=20;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); hideNav();
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},REQ);
        else start(); }
    void start(){ FrameLayout root=new FrameLayout(this); camera=new CameraController(this); root.addView(camera); ui=new LiquidUI(this,camera); root.addView(ui); setContentView(root); }
    void hideNav(){ getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_STABLE); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==REQ && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) start(); else Toast.makeText(this,"Izin kamera diperlukan",Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume(); if(camera!=null) camera.open();}
    @Override protected void onPause(){if(camera!=null) camera.close(); super.onPause();}
}

class CameraController extends TextureView implements TextureView.SurfaceTextureListener {
    Activity a; CameraDevice device; CameraCaptureSession session; String cameraId; boolean front=false, recording=false; float zoom=1f; Size previewSize; MediaRecorder recorder; ImageReaderProxy reader; HandlerThread ht; Handler h;
    CameraController(Activity a){super(a);this.a=a;setSurfaceTextureListener(this); ht=new HandlerThread("cam");ht.start();h=new Handler(ht.getLooper());}
    void open(){ if(Build.VERSION.SDK_INT<23 || a.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return; CameraManager m=(CameraManager)a.getSystemService(Context.CAMERA_SERVICE); try{ cameraId=findId(m,front); CameraCharacteristics c=m.getCameraCharacteristics(cameraId); StreamConfigurationMap map=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP); previewSize=map.getOutputSizes(SurfaceTexture.class)[0]; m.openCamera(cameraId,new CameraDevice.StateCallback(){public void onOpened(CameraDevice d){device=d;startPreview();}public void onDisconnected(CameraDevice d){d.close();device=null;}public void onError(CameraDevice d,int e){d.close();device=null;}},h);}catch(Exception e){toast("Kamera tidak bisa dibuka");}}
    String findId(CameraManager m,boolean f)throws Exception{for(String id:m.getCameraIdList()){Integer x=m.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);if((f&&x==CameraCharacteristics.LENS_FACING_FRONT)||(!f&&x==CameraCharacteristics.LENS_FACING_BACK))return id;}return m.getCameraIdList()[0];}
    void startPreview(){ if(device==null||!isAvailable())return; try{SurfaceTexture st=getSurfaceTexture();st.setDefaultBufferSize(getWidth(),getHeight());Surface s=new Surface(st); CaptureRequest.Builder b=device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);b.addTarget(s);b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);applyZoom(b);device.createCaptureSession(Collections.singletonList(s),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession cs){session=cs;try{cs.setRepeatingRequest(b.build(),null,h);}catch(Exception ignored){}}public void onConfigureFailed(CameraCaptureSession cs){}},h);}catch(Exception e){}}
    void applyZoom(CaptureRequest.Builder b){try{CameraManager m=(CameraManager)a.getSystemService(Context.CAMERA_SERVICE);Rect r=m.getCameraCharacteristics(cameraId).get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);if(r!=null){float z=Math.max(1f,Math.min(4f,zoom));int w=(int)(r.width()/z),hh=(int)(r.height()/z);int l=(r.width()-w)/2,t=(r.height()-hh)/2;b.set(CaptureRequest.SCALER_CROP_REGION,new Rect(l,t,l+w,t+hh));}}catch(Exception ignored){}}
    void takePhoto(){if(device==null||session==null)return;try{CameraManager m=(CameraManager)a.getSystemService(Context.CAMERA_SERVICE);ImageReaderProxy ir=new ImageReaderProxy(a);reader=ir;Surface out=ir.surface;CaptureRequest.Builder b=device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);b.addTarget(out);applyZoom(b);b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);session.stopRepeating();session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){public void onCaptureCompleted(CameraCaptureSession s,CaptureRequest r,TotalCaptureResult x){startPreview();}},h);}catch(Exception e){toast("Foto gagal");}}
    void toggleCamera(){front=!front;close();open();}
    void setZoom(float z){zoom=z;if(session!=null)startPreview();}
    void toggleVideo(){ if(recording) stopVideo(); else startVideo(); }
    void startVideo(){if(device==null)return;try{recorder=new MediaRecorder();File f=new File(a.getExternalFilesDir(null),"Liquid_"+System.currentTimeMillis()+".mp4");recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setVideoSize(1280,720);recorder.setVideoFrameRate(30);recorder.setVideoEncodingBitRate(5000000);recorder.setOutputFile(f.getAbsolutePath());recorder.prepare();SurfaceTexture st=getSurfaceTexture();st.setDefaultBufferSize(1280,720);Surface preview=new Surface(st);Surface rec=recorder.getSurface();CaptureRequest.Builder b=device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);b.addTarget(preview);b.addTarget(rec);applyZoom(b);device.createCaptureSession(Arrays.asList(preview,rec),new CameraCaptureSession.StateCallback(){public void onConfigured(CameraCaptureSession c){session=c;try{c.setRepeatingRequest(b.build(),null,h);recorder.start();recording=true;toast("Video direkam");}catch(Exception e){}}public void onConfigureFailed(CameraCaptureSession c){}},h);}catch(Exception e){toast("Video tidak didukung di mode ini");}}
    void stopVideo(){try{recorder.stop();recorder.reset();recording=false;toast("Video tersimpan di folder aplikasi");startPreview();}catch(Exception e){recording=false;}}
    void close(){if(session!=null){try{session.close();}catch(Exception ignored){}session=null;}if(device!=null){try{device.close();}catch(Exception ignored){}device=null;}}
    void toast(String s){a.runOnUiThread(()->Toast.makeText(a,s,Toast.LENGTH_SHORT).show());}
    public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){open();} public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){} public boolean onSurfaceTextureDestroyed(SurfaceTexture s){close();return true;} public void onSurfaceTextureUpdated(SurfaceTexture s){}
}

class ImageReaderProxy {
    android.media.ImageReader ir; Surface surface; Activity a;
    ImageReaderProxy(Activity a){this.a=a;ir=android.media.ImageReader.newInstance(1280,720,android.graphics.ImageFormat.JPEG,2);surface=ir.getSurface();ir.setOnImageAvailableListener(r->{android.media.Image im=r.acquireLatestImage();if(im==null)return;try{ByteBufferData b=new ByteBufferData(im);String n="IMG_"+System.currentTimeMillis()+".jpg";File f=new File(a.getExternalFilesDir(null),n);FileOutputStream o=new FileOutputStream(f);o.write(b.bytes);o.close();a.runOnUiThread(()->Toast.makeText(a,"Foto tersimpan: "+n,Toast.LENGTH_SHORT).show());}catch(Exception ignored){}finally{im.close();}},new Handler(Looper.getMainLooper()));}
}
class ByteBufferData {byte[] bytes; ByteBufferData(android.media.Image i){java.nio.ByteBuffer b=i.getPlanes()[0].getBuffer();bytes=new byte[b.remaining()];b.get(bytes);}}

class LiquidUI extends View {
    Paint p=new Paint(3); Paint text=new Paint(3); CameraController c; float d; RectF r=new RectF();
    LiquidUI(Context x,CameraController c){super(x);this.c=c;d=getResources().getDisplayMetrics().density;text.setTypeface(Typeface.create("sans",Typeface.NORMAL));setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    void glass(Canvas x,float l,float t,float rr,float bb,float rad){p.setStyle(Paint.Style.FILL);p.setColor(0x66333333);p.setShadowLayer(12,0,4,0x66000000);x.drawRoundRect(l,t,rr,bb,rad,rad,p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f);p.setColor(0x88FFFFFF);x.drawRoundRect(l,t,rr,bb,rad,rad,p);p.setStyle(Paint.Style.FILL);}
    void txt(Canvas x,String s,float xx,float yy,float size,int color,Paint.Align align){text.setTextSize(size*d);text.setColor(color);text.setTextAlign(align);x.drawText(s,xx,yy,text);}
    protected void onDraw(Canvas x){super.onDraw(x);float w=getWidth(),h=getHeight();
        // top glass controls
        glass(x,w*.47f,18*d,w-14*d,58*d,22*d);txt(x,"FHD",w*.50f,44*d,14,Color.WHITE,Paint.Align.CENTER);txt(x,"30",w*.60f,44*d,14,Color.WHITE,Paint.Align.CENTER);txt(x,"⚡",w*.69f,45*d,17,Color.WHITE,Paint.Align.CENTER);txt(x,"••",w*.78f,39*d,20,Color.WHITE,Paint.Align.CENTER);
        // zoom
        float zy=h-145*d;txt(x,"0,5",w*.36f,zy,15,Color.WHITE,Paint.Align.CENTER);txt(x,"1x",w*.46f,zy,16,0xFFFFE85A,Paint.Align.CENTER);txt(x,"2",w*.56f,zy,15,Color.WHITE,Paint.Align.CENTER);txt(x,"3",w*.66f,zy,15,Color.WHITE,Paint.Align.CENTER);
        // shutter
        float cy=h-91*d; p.setStyle(Paint.Style.FILL);p.setColor(0x99FFFFFF);x.drawCircle(w/2,cy,39*d,p);p.setColor(c.recording?0xFFFF3333:0xFFFF3038);x.drawCircle(w/2,cy,31*d,p);p.setStyle(Paint.Style.FILL);
        // bottom glass mode selector
        glass(x,w*.25f,h-58*d,w*.75f,h-16*d,22*d);txt(x,"SHORT",w*.39f,h-31*d,14,0xFFFFE85A,Paint.Align.CENTER);txt(x,"VIDEO",w*.61f,h-31*d,14,Color.WHITE,Paint.Align.CENTER);
        // gallery + flip
        glass(x,18*d,h-58*d,72*d,h-16*d,22*d);txt(x,"◉",45*d,h-31*d,23,Color.WHITE,Paint.Align.CENTER);glass(x,w-72*d,h-58*d,w-18*d,h-16*d,22*d);txt(x,"↻",w-45*d,h-30*d,25,Color.WHITE,Paint.Align.CENTER);
    }
    public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
        if(y>h-135*d && y<h-55*d && x>w*.35f&&x<w*.65f){c.takePhoto();invalidate();return true;}
        if(y>h-70*d && x>w*.75f){c.toggleCamera();return true;}
        if(y>h-70*d && x<w*.22f)return true;
        if(y>h-65*d && x>w*.23f&&x<w*.77f){ if(x<w*.5f)c.takePhoto(); else c.toggleVideo(); invalidate(); return true;}
        if(y>h-175*d&&y<h-115*d){if(x<w*.41f)c.setZoom(.5f);else if(x<w*.51f)c.setZoom(1f);else if(x<w*.61f)c.setZoom(2f);else c.setZoom(3f);invalidate();return true;}
        return true; }
}
